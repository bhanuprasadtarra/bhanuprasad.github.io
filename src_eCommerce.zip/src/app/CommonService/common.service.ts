import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  isValidUser: BehaviorSubject<boolean> = new BehaviorSubject(false);
  cartCount: BehaviorSubject<number> = new BehaviorSubject(0);

  constructor() { }

  setValidUser(valid: boolean) {
    this.isValidUser.next(valid);
  }
  getValidUser() {
    return this.isValidUser.asObservable();
  }

  setCartCount(value: number) {
    this.cartCount.next(value);
  }
  getCartCount() {
    return this.cartCount.asObservable();
  }
}
