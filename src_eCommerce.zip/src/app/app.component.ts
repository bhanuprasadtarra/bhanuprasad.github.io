import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from './CommonService/common.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'eCommerce';
  isValidUser: boolean = false;
  cartCount: number = 0;
  constructor(private commonService: CommonService, private router: Router) {

  }
  ngOnInit() {
    this.commonService.getValidUser().subscribe(res => {
      this.isValidUser = res;
    });
    this.commonService.getCartCount().subscribe(res => {
      this.cartCount = res;
    });
    // let items = ProductsData.map(function(ele) {
    //   return ele.AddedToCart
    // })
    // this.cartCount = items.length;
  }

  btnCartClick() {
    this.router.navigate(['/cart']);
  }

  goToHome() {
    this.router.navigate(['/home']);
  }
  
  logOut() {
    this.commonService.setValidUser(false);
    this.router.navigate(['']);
  }
}
