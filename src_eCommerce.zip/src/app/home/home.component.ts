import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { CommonService } from '../CommonService/common.service';
import { ProductsData, ProuductData } from '../ProductsData';
import { AddProductComponent } from './add-product/add-product.component';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = ['productName', 'amount', 'addToCart', 'deleteProduct'];
  dataSource = new MatTableDataSource<ProuductData>(ProductsData);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  cartCount: number;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  constructor(private commonService: CommonService, private router: Router, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.commonService.getValidUser().subscribe(res => {
      if (res == false) {
        this.router.navigate(['']);
      }
    });
  }

  deleteProduct(iter: number) {
    ProductsData.splice(iter, 1);
    this.dataSource.data = ProductsData;
    this.updaeCartCount();
  }

  addProduct() {
    let items = ProductsData.map(function (ele) { return ele.productId })
    let maxId = Math.max.apply(Math, items);
    const dialogRef = this.dialog.open(AddProductComponent,
      {
        width: '500px',
        height: '300px',
        data: {
          DialogType: 'AddProduct',
          lengthArr: maxId
        }
      });
    dialogRef.afterClosed().subscribe(data => {
      this.dataSource.data = ProductsData;
    }
    );
  }

  addToCart(element, iter) {
    ProductsData[iter].AddedToCart = true;
    this.dataSource.data = ProductsData;
    this.updaeCartCount();
  }
  updaeCartCount() {
    this.cartCount = 0;
    ProductsData.filter(ele => {
      if (ele.AddedToCart == true) {
        this.cartCount += 1;
      }
    });
    this.commonService.setCartCount(this.cartCount);
  }
}
