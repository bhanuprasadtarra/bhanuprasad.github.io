import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ProductsData, ProuductData } from '../../ProductsData';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  dialogType: string;
  len: number;
  addNewProduct: FormGroup = new FormGroup({
    productName: new FormControl('', [Validators.required]),
    amount: new FormControl('', [Validators.required])
  });

  constructor(public dialogRef: MatDialogRef<AddProductComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
    this.dialogType = this.data.DialogType;
    if (this.dialogType == 'AddProduct') {
      this.len = this.data.lengthArr;
    }
  }

  addProductSubmit() {
    if(this.addNewProduct.valid)
    {
      let item = {
        productName: this.addNewProduct.value.productName,
        price: this.addNewProduct.value.productName,
        productId: this.len+1,
        AddedToCart: false
      }
      ProductsData.push(item)
      this.dialogRef.close();
    }
  }



}
