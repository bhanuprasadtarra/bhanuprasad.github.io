import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CommonService } from '../CommonService/common.service';
import { AddProductComponent } from '../home/add-product/add-product.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  signUpResponse: any;
  invalidCred: boolean = false;
  logInBtnVisible = true;
  formLogin: FormGroup = new FormGroup({
    userName: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required])
  })
  constructor(private commonService: CommonService, private router: Router, private dialog: MatDialog) { }

  ngOnInit(): void {
  }

  login() {
    if (this.formLogin.valid) {
      let UserName = this.formLogin.value.userName;
      let pwd = this.formLogin.value.password;
      this.logInBtnVisible = false;
      if (UserName == 'user' && pwd == 'User@123') {
        this.commonService.setValidUser(true);
        localStorage.setItem('userSession', JSON.stringify('validUser'));
          this.router.navigate(['/home']);
      } else {
        this.invalidCred = true;
        this.logInBtnVisible = true;
      }

    }
  }

  help() {
    const dialogRef = this.dialog.open(AddProductComponent,
      {
        width: '300px',
        height: '200px',
        data: {
          DialogType: 'help',
          lengthArr: 0
        }
      });
      dialogRef.afterClosed().subscribe();
  }
}
