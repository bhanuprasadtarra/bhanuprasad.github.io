import { AfterViewInit, Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { CommonService } from '../CommonService/common.service';
import { ProductsData, ProuductData } from '../ProductsData';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  displayedColumns: string[] = ['productName', 'amount', 'deleteProduct'];
  cartData: ProuductData[] = [];
  dataSource;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  cartCount: number;
  totalCost: number = 0;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  constructor(private commonService: CommonService, private router: Router, private changeDetectorRefs: ChangeDetectorRef, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.commonService.getValidUser().subscribe(res => {
      if (res == false) {
        this.router.navigate(['']);
      }
    });
    this.getCartData();
  }

  getCartData() {
    this.cartData = [];
    ProductsData.filter(ele => {
      if (ele.AddedToCart == true) {
        this.cartData.push(ele);
      }
    });
    this.dataSource = new MatTableDataSource<ProuductData>(this.cartData);
    this.totalCartAmount();
  }

  totalCartAmount() {
    this.totalCost = 0;
    this.cartData.filter(ele => {
      this.totalCost += ele.price
    });
  }

  deleteFromCart(iter) {
    let index = ProductsData.findIndex(x => x.productId === (this.cartData[iter].productId));
    ProductsData[index].AddedToCart = false;
    this.getCartData();
    this.dataSource.data = this.cartData;
    this.updaeCartCount();
  }
  updaeCartCount() {
    this.cartCount = 0;
    ProductsData.filter(ele => {
      if (ele.AddedToCart == true) {
        this.cartCount += 1;
      }
    });
    this.commonService.setCartCount(this.cartCount);
  }

}
