export interface ProuductData {
    productId: number;
    productName: string;
    price: number;
    AddedToCart: boolean;
  }
  
  export const ProductsData: ProuductData[] = [
    {productId: 0,productName: 'Wireless Phone Charger', price: 20, AddedToCart: false},
    {productId: 1,productName: 'Face Shield', price: 3, AddedToCart: false},
    {productId: 2,productName: 'Smart Band AMOLED Display', price: 190, AddedToCart: false},
    {productId: 3,productName: 'Garden Hose', price: 10, AddedToCart: false},
    {productId: 4,productName: 'Safety Shoes', price: 35, AddedToCart: false},
    {productId: 5,productName: 'Cleaning Liquids', price: 3, AddedToCart: false},
    {productId: 6,productName: 'Water Purification', price: 150, AddedToCart: false},
    {productId: 7,productName: 'Phone Lense', price: 8, AddedToCart: false},
    {productId: 8,productName: '32-inch Class LED Smart FHD TV', price: 270, AddedToCart: false},
    {productId: 9,productName: 'Electric Spice and Coffee Grinder', price: 20, AddedToCart: false},
  ];